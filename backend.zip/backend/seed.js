require('dotenv').config();
const mongoose = require('mongoose');
const Movie = require('./models/Movie');

const MONGO = process.env.MONGO_URI || 'mongodb://localhost:27017/moviedb';

// Generate showtimes for the next 7 days
function generateShowtimes() {
  const showtimes = [];
  const now = new Date();
  for (let day = 0; day < 7; day++) {
    const date = new Date(now);
    date.setDate(date.getDate() + day);
    date.setHours(18, 0, 0, 0); // 6 PM
    showtimes.push(new Date(date));
    date.setHours(21, 0, 0, 0); // 9 PM
    showtimes.push(new Date(date));
  }
  return showtimes;
}

const data = [
  { 
    title: 'The Matrix', 
    director: 'Wachowskis', 
    year: 1999, 
    genre: 'Sci-Fi', 
    rating: 8.7, 
    poster: 'https://i.imgur.com/3jLPB46.jpg',
    description: 'A computer hacker learns from mysterious rebels about the true nature of his reality and his role in the war against its controllers.',
    duration: 136,
    price: 12.99,
    cast: ['Keanu Reeves', 'Laurence Fishburne', 'Carrie-Anne Moss'],
    showtimes: generateShowtimes(),
    isActive: true
  },
  { 
    title: 'Inception', 
    director: 'Christopher Nolan', 
    year: 2010, 
    genre: 'Sci-Fi', 
    rating: 8.8, 
    poster: 'https://i.imgur.com/2l5uGQw.jpg',
    description: 'A skilled thief is given a chance at redemption if he can pull off an impossible task: inception, planting an idea in someone\'s mind.',
    duration: 148,
    price: 13.99,
    cast: ['Leonardo DiCaprio', 'Marion Cotillard', 'Tom Hardy'],
    showtimes: generateShowtimes(),
    isActive: true
  },
  { 
    title: 'Interstellar', 
    director: 'Christopher Nolan', 
    year: 2014, 
    genre: 'Sci-Fi', 
    rating: 8.6, 
    poster: 'https://i.imgur.com/rC9Q5QA.jpg',
    description: 'A team of explorers travel through a wormhole in space in an attempt to ensure humanity\'s survival.',
    duration: 169,
    price: 14.99,
    cast: ['Matthew McConaughey', 'Anne Hathaway', 'Jessica Chastain'],
    showtimes: generateShowtimes(),
    isActive: true
  }
];

mongoose.connect(MONGO).then(async () => {
  await Movie.deleteMany({});
  await Movie.insertMany(data);
  console.log('Seeded database');
  mongoose.disconnect();
}).catch(err => console.error(err));
