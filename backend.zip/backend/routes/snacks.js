const express = require('express');
const router = express.Router();
const Snack = require('../models/Snack');

// GET all snacks
router.get('/', async (req, res) => {
  try {
    const snacks = await Snack.find({ available: true }).sort({ category: 1, name: 1 });
    res.json(snacks);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET snack by ID
router.get('/:id', async (req, res) => {
  try {
    const snack = await Snack.findById(req.params.id);
    if (!snack) return res.status(404).json({ error: 'Not found' });
    res.json(snack);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST create snack (admin)
router.post('/', async (req, res) => {
  try {
    const snack = new Snack(req.body);
    await snack.save();
    res.status(201).json(snack);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// PUT update snack (admin)
router.put('/:id', async (req, res) => {
  try {
    const snack = await Snack.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!snack) return res.status(404).json({ error: 'Not found' });
    res.json(snack);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

module.exports = router;

