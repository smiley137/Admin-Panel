const express = require('express');
const router = express.Router();
const Booking = require('../models/Booking');
const Seat = require('../models/Seat');
const Movie = require('../models/Movie');
const Snack = require('../models/Snack');

// GET all bookings (admin sees all, user sees only their own)
router.get('/', async (req, res) => {
  try {
    const filter = req.user.role === 'admin' ? {} : { userId: req.user._id.toString() };
    const bookings = await Booking.find(filter)
      .populate('movieId', 'title poster')
      .populate('snacks.snackId')
      .sort({ createdAt: -1 });
    res.json(bookings);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET booking by ID
router.get('/:id', async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.id)
      .populate('movieId')
      .populate('snacks.snackId');
    if (!booking) return res.status(404).json({ error: 'Not found' });
    res.json(booking);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST create booking
router.post('/', async (req, res) => {
  try {
    const { movieId, seats, snacks, showtime, totalAmount } = req.body;
    
    // Check if seats are available
    const showtimeDate = new Date(showtime);
    for (const seat of seats) {
      const existingSeat = await Seat.findOne({
        movieId,
        showtime: showtimeDate,
        row: seat.row,
        number: seat.number,
        isBooked: true
      });
      if (existingSeat) {
        return res.status(400).json({ error: `Seat ${seat.row}${seat.number} is already booked` });
      }
    }

    // Create booking
    const booking = new Booking({
      movieId,
      userId: req.user._id.toString(),
      seats,
      snacks: snacks || [],
      showtime: showtimeDate,
      totalAmount,
      paymentStatus: 'pending'
    });
    await booking.save();

    // Mark seats as booked
    for (const seat of seats) {
      await Seat.findOneAndUpdate(
        { movieId, showtime: showtimeDate, row: seat.row, number: seat.number },
        { isBooked: true, bookingId: booking._id },
        { upsert: true, new: true }
      );
    }

    res.status(201).json(booking);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// PUT update booking (for payment)
router.put('/:id/payment', async (req, res) => {
  try {
    const { paymentId, paymentStatus } = req.body;
    const booking = await Booking.findByIdAndUpdate(
      req.params.id,
      { paymentId, paymentStatus: paymentStatus || 'completed' },
      { new: true }
    );
    if (!booking) return res.status(404).json({ error: 'Not found' });
    res.json(booking);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

module.exports = router;

