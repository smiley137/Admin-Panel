const express = require('express');
const router = express.Router();
const Seat = require('../models/Seat');

// GET available seats for a movie showtime
router.get('/:movieId/:showtime', async (req, res) => {
  try {
    const { movieId, showtime } = req.params;
    const showtimeDate = new Date(decodeURIComponent(showtime));
    const seats = await Seat.find({
      movieId,
      showtime: showtimeDate
    });
    
    // Generate all seats if none exist (10 rows, 10 seats per row)
    if (seats.length === 0) {
      const rows = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J'];
      const allSeats = [];
      for (const row of rows) {
        for (let num = 1; num <= 10; num++) {
          allSeats.push({
            movieId,
            showtime: showtimeDate,
            row,
            number: num,
            isBooked: false
          });
        }
      }
      await Seat.insertMany(allSeats);
      const updatedSeats = await Seat.find({
        movieId,
        showtime: showtimeDate
      });
      return res.json(updatedSeats);
    }
    
    res.json(seats);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;

