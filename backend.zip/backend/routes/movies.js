const express = require('express');
const router = express.Router();
const Movie = require('../models/Movie');
const { verifyToken, isAdmin } = require('../middleware/auth');

// GET /api/movies (public - only active movies)
router.get('/', async (req, res) => {
  try {
    const q = req.query.q || '';
    const admin = req.query.admin === 'true'; // Admin can see all movies
    const filter = q ? { title: { $regex: q, $options: 'i' } } : {};
    if (!admin) {
      filter.isActive = true; // Only show active movies to public
    }
    const movies = await Movie.find(filter).sort({ createdAt: -1 }).limit(100);
    res.json(movies);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const movie = await Movie.findById(req.params.id);
    if (!movie) return res.status(404).json({ error: 'Not found' });
    res.json(movie);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Utility to normalize showtimes in the request body
function normalizeMoviePayload(body) {
  const payload = { ...body };
  if (Array.isArray(payload.showtimes)) {
    payload.showtimes = payload.showtimes
      .map(st => {
        // Accept Date, ISO string, or local 'YYYY-MM-DDTHH:mm'
        const d = (st instanceof Date) ? st : new Date(st);
        return isNaN(d.getTime()) ? null : d;
      })
      .filter(Boolean);
  }
  return payload;
}

// Admin only routes
router.post('/', verifyToken, isAdmin, async (req, res) => {
  try {
    const payload = normalizeMoviePayload(req.body);
    const movie = new Movie(payload);
    await movie.save();
    res.status(201).json(movie);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

router.put('/:id', verifyToken, isAdmin, async (req, res) => {
  try {
    const payload = normalizeMoviePayload(req.body);
    const movie = await Movie.findByIdAndUpdate(
      req.params.id,
      payload,
      { new: true, runValidators: true }
    );
    if (!movie) return res.status(404).json({ error: 'Not found' });
    res.json(movie);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

router.delete('/:id', verifyToken, isAdmin, async (req, res) => {
  try {
    const movie = await Movie.findByIdAndDelete(req.params.id);
    if (!movie) return res.status(404).json({ error: 'Not found' });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
