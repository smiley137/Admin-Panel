require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const authRoutes = require('./routes/auth');
const moviesRoutes = require('./routes/movies');
const bookingsRoutes = require('./routes/bookings');
const seatsRoutes = require('./routes/seats');
const snacksRoutes = require('./routes/snacks');
const { verifyToken, isAdmin } = require('./middleware/auth');

const app = express();
app.use(cors());
app.use(express.json());

// Public routes
app.use('/api/auth', authRoutes);
app.use('/api/movies', moviesRoutes);
app.use('/api/seats', seatsRoutes);
app.use('/api/snacks', snacksRoutes);

// Protected routes
app.use('/api/bookings', verifyToken, bookingsRoutes);

const PORT = process.env.PORT || 5000;
const MONGO = process.env.MONGO_URI || 'mongodb://localhost:27017/moviedb';

mongoose.connect(MONGO)
  .then(() => {
    console.log('Connected to MongoDB');
    app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
  })
  .catch(err => {
    console.error('MongoDB connection error:', err.message);
  });
