const mongoose = require('mongoose');

const SeatSchema = new mongoose.Schema({
  movieId: { type: mongoose.Schema.Types.ObjectId, ref: 'Movie', required: true },
  showtime: { type: Date, required: true },
  row: { type: String, required: true },
  number: { type: Number, required: true },
  isBooked: { type: Boolean, default: false },
  bookingId: { type: mongoose.Schema.Types.ObjectId, ref: 'Booking' }
}, { timestamps: true });

// Compound index to ensure unique seats per showtime
SeatSchema.index({ movieId: 1, showtime: 1, row: 1, number: 1 }, { unique: true });

module.exports = mongoose.model('Seat', SeatSchema);

