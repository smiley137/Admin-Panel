const mongoose = require('mongoose');

const SnackSchema = new mongoose.Schema({
  name: { type: String, required: true },
  description: { type: String },
  price: { type: Number, required: true },
  image: { type: String },
  category: { type: String, enum: ['popcorn', 'drinks', 'candy', 'combo'], default: 'popcorn' },
  available: { type: Boolean, default: true }
}, { timestamps: true });

module.exports = mongoose.model('Snack', SnackSchema);

