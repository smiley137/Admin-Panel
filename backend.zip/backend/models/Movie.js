const mongoose = require('mongoose');

const MovieSchema = new mongoose.Schema({
  title: { type: String, required: true },
  director: { type: String },
  year: { type: Number },
  genre: { type: String },
  rating: { type: Number, min: 0, max: 10 },
  poster: { type: String }, // url
  description: { type: String },
  duration: { type: Number }, // in minutes
  showtimes: [{ type: Date }], // array of available showtimes
  price: { type: Number, default: 10 }, // ticket price
  trailer: { type: String }, // trailer URL
  cast: [{ type: String }], // array of cast members
  language: { type: String, default: 'English' },
  isActive: { type: Boolean, default: true } // to show/hide from user website
}, { timestamps: true });

module.exports = mongoose.model('Movie', MovieSchema);
