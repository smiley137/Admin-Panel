const mongoose = require('mongoose');

const BookingSchema = new mongoose.Schema({
  movieId: { type: mongoose.Schema.Types.ObjectId, ref: 'Movie', required: true },
  userId: { type: String, default: 'guest' }, // Can be enhanced with user auth later
  seats: [{ 
    row: { type: String, required: true },
    number: { type: Number, required: true }
  }],
  snacks: [{
    snackId: { type: mongoose.Schema.Types.ObjectId, ref: 'Snack' },
    quantity: { type: Number, default: 1 }
  }],
  showtime: { type: Date, required: true },
  totalAmount: { type: Number, required: true },
  paymentStatus: { type: String, enum: ['pending', 'completed', 'failed'], default: 'pending' },
  paymentId: { type: String },
  bookingDate: { type: Date, default: Date.now }
}, { timestamps: true });

module.exports = mongoose.model('Booking', BookingSchema);

