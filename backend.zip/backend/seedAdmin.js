require('dotenv').config();
const mongoose = require('mongoose');
const User = require('./models/User');

const MONGO = process.env.MONGO_URI || 'mongodb://localhost:27017/moviedb';

mongoose.connect(MONGO).then(async () => {
  // Check if admin exists
  const existingAdmin = await User.findOne({ email: 'admin@moviehub.com' });
  if (existingAdmin) {
    console.log('Admin user already exists');
    mongoose.disconnect();
    return;
  }

  // Create admin user
  const admin = new User({
    name: 'Admin',
    email: 'admin@moviehub.com',
    password: 'admin123', // Will be hashed automatically
    role: 'admin'
  });

  await admin.save();
  console.log('Admin user created:');
  console.log('Email: admin@moviehub.com');
  console.log('Password: admin123');
  mongoose.disconnect();
}).catch(err => console.error(err));

