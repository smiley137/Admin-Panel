require('dotenv').config();
const mongoose = require('mongoose');
const Snack = require('./models/Snack');

const MONGO = process.env.MONGO_URI || 'mongodb://localhost:27017/moviedb';

const snacks = [
  { name: 'Small Popcorn', description: 'Freshly popped, buttery goodness', price: 5.99, category: 'popcorn', image: 'https://via.placeholder.com/300x200?text=Small+Popcorn' },
  { name: 'Medium Popcorn', description: 'Perfect size for sharing', price: 7.99, category: 'popcorn', image: 'https://via.placeholder.com/300x200?text=Medium+Popcorn' },
  { name: 'Large Popcorn', description: 'The ultimate movie snack', price: 9.99, category: 'popcorn', image: 'https://via.placeholder.com/300x200?text=Large+Popcorn' },
  { name: 'Coca Cola', description: 'Classic cola drink', price: 4.99, category: 'drinks', image: 'https://via.placeholder.com/300x200?text=Coca+Cola' },
  { name: 'Pepsi', description: 'Refreshing cola', price: 4.99, category: 'drinks', image: 'https://via.placeholder.com/300x200?text=Pepsi' },
  { name: 'Sprite', description: 'Lemon-lime soda', price: 4.99, category: 'drinks', image: 'https://via.placeholder.com/300x200?text=Sprite' },
  { name: 'Water', description: 'Pure bottled water', price: 3.99, category: 'drinks', image: 'https://via.placeholder.com/300x200?text=Water' },
  { name: 'M&M\'s', description: 'Chocolate candies', price: 4.99, category: 'candy', image: 'https://via.placeholder.com/300x200?text=M%26Ms' },
  { name: 'Skittles', description: 'Taste the rainbow', price: 4.99, category: 'candy', image: 'https://via.placeholder.com/300x200?text=Skittles' },
  { name: 'Nachos', description: 'Cheesy nachos with jalapeños', price: 6.99, category: 'combo', image: 'https://via.placeholder.com/300x200?text=Nachos' },
  { name: 'Hot Dog', description: 'Classic cinema hot dog', price: 5.99, category: 'combo', image: 'https://via.placeholder.com/300x200?text=Hot+Dog' },
  { name: 'Combo Deal', description: 'Large popcorn + 2 drinks', price: 15.99, category: 'combo', image: 'https://via.placeholder.com/300x200?text=Combo+Deal' }
];

mongoose.connect(MONGO).then(async () => {
  await Snack.deleteMany({});
  await Snack.insertMany(snacks);
  console.log('Seeded snacks database');
  mongoose.disconnect();
}).catch(err => console.error(err));

