import axios from 'axios'
const API = axios.create({ baseURL: import.meta.env.VITE_API_URL || 'http://localhost:5000/api' })

// Add token to requests if available
const token = localStorage.getItem('token')
if (token) {
  API.defaults.headers.common['Authorization'] = `Bearer ${token}`
}

API.interceptors.request.use((config) => {
  const activeToken = localStorage.getItem('token')
  if (activeToken) {
    config.headers.Authorization = `Bearer ${activeToken}`
  } else {
    delete config.headers.Authorization
  }
  return config
})

export default API
