import React, { createContext, useState, useEffect, useContext } from 'react'
import API from '../api'

const AuthContext = createContext()

export function useAuth() {
  return useContext(AuthContext)
}

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const token = localStorage.getItem('token')
    if (token) {
      API.defaults.headers.common['Authorization'] = `Bearer ${token}`
      fetchUser()
    } else {
      setLoading(false)
    }
  }, [])

  async function fetchUser() {
    try {
      const res = await API.get('/auth/me')
      setUser(res.data.user)
    } catch (err) {
      localStorage.removeItem('token')
      delete API.defaults.headers.common['Authorization']
      setUser(null)
    }
    setLoading(false)
  }

  async function login(email, password) {
    const res = await API.post('/auth/login', { email, password })
    const { token, user } = res.data
    localStorage.setItem('token', token)
    API.defaults.headers.common['Authorization'] = `Bearer ${token}`
    setUser(user)
    return user
  }

  async function register(name, email, password, phone) {
    const res = await API.post('/auth/register', { name, email, password, phone })
    const { token, user } = res.data
    localStorage.setItem('token', token)
    API.defaults.headers.common['Authorization'] = `Bearer ${token}`
    setUser(user)
    return user
  }

  function logout() {
    localStorage.removeItem('token')
    delete API.defaults.headers.common['Authorization']
    setUser(null)
  }

  const value = {
    user,
    login,
    register,
    logout,
    loading
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

