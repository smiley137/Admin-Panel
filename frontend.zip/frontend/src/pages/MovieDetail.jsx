import React, { useEffect, useState } from 'react'
import { useParams, Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import API from '../api'

export default function MovieDetail(){
  const { id } = useParams()
  const navigate = useNavigate()
  const { user } = useAuth()
  const [movie, setMovie] = useState(null)
  const [loading, setLoading] = useState(true)
  const [selectedShowtime, setSelectedShowtime] = useState(null)

  useEffect(() => {
    async function fetchMovie(){
      try {
        const res = await API.get('/movies/' + id)
        setMovie(res.data)
        if (res.data.showtimes && res.data.showtimes.length > 0) {
          setSelectedShowtime(res.data.showtimes[0])
        }
      } catch (err) {
        console.error('Error fetching movie:', err)
      }
      setLoading(false)
    }
    fetchMovie()
  }, [id])

  function handleBookTicket(){
    if (!user) {
      navigate('/login')
      return
    }
    if (!selectedShowtime) {
      alert('Please select a showtime')
      return
    }
    navigate(`/booking/${id}?showtime=${new Date(selectedShowtime).toISOString()}`)
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-black flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-16 w-16 border-b-2 border-yellow-400"></div>
          <p className="mt-4 text-gray-300">Loading movie details...</p>
        </div>
      </div>
    )
  }

  if (!movie) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-black flex items-center justify-center">
        <div className="text-center">
          <div className="text-6xl mb-4">🎭</div>
          <p className="text-gray-300 text-xl mb-4">Movie not found</p>
          <Link to="/" className="text-yellow-400 hover:text-yellow-300 font-semibold">Go back home</Link>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-black">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-black/80 backdrop-blur-md border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link to="/" className="flex items-center space-x-2">
              <div className="w-10 h-10 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-lg flex items-center justify-center">
                <span className="text-xl">🎬</span>
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-yellow-400 to-orange-500 bg-clip-text text-transparent">
                MovieHub
              </span>
            </Link>
            <Link to="/" className="text-gray-300 hover:text-white transition-colors">
              ← Back to Movies
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section with Movie Poster */}
      <div className="relative pt-16">
        <div 
          className="absolute inset-0 h-[60vh] bg-cover bg-center"
          style={{
            backgroundImage: `linear-gradient(to bottom, rgba(0,0,0,0.4), rgba(0,0,0,0.9)), url(${movie.poster || 'https://via.placeholder.com/1920x1080'})`
          }}
        >
          <div className="absolute inset-0 bg-gradient-to-r from-black/90 via-black/70 to-transparent"></div>
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Poster */}
            <div className="lg:col-span-1">
              <div className="sticky top-24">
                <div className="relative group">
                  <img
                    src={movie.poster || 'https://via.placeholder.com/400x600?text=No+Poster'}
                    alt={movie.title}
                    className="w-full rounded-2xl shadow-2xl transform group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity"></div>
                </div>
              </div>
            </div>

            {/* Details */}
            <div className="lg:col-span-2 text-white">
              <h1 className="text-4xl md:text-6xl font-bold mb-4 bg-gradient-to-r from-yellow-400 to-orange-500 bg-clip-text text-transparent">
                {movie.title}
              </h1>
              
              <div className="flex flex-wrap items-center gap-4 mb-6">
                {movie.rating && (
                  <div className="flex items-center gap-2 bg-yellow-400/20 px-4 py-2 rounded-full border border-yellow-400/50">
                    <span className="text-yellow-400 text-xl">⭐</span>
                    <span className="font-bold text-white">{movie.rating.toFixed(1)}/10</span>
                  </div>
                )}
                {movie.year && (
                  <span className="text-gray-300 font-medium">{movie.year}</span>
                )}
                {movie.genre && (
                  <span className="text-gray-300">• {movie.genre}</span>
                )}
                {movie.duration && (
                  <span className="text-gray-300">• {movie.duration} min</span>
                )}
                {movie.language && (
                  <span className="text-gray-300">• {movie.language}</span>
                )}
              </div>

              {movie.director && (
                <div className="mb-4">
                  <span className="text-gray-400">Director: </span>
                  <span className="text-white font-semibold">{movie.director}</span>
                </div>
              )}

              {movie.cast && movie.cast.length > 0 && (
                <div className="mb-6">
                  <span className="text-gray-400">Cast: </span>
                  <span className="text-white">{movie.cast.join(', ')}</span>
                </div>
              )}

              {movie.description && (
                <div className="mb-8">
                  <h2 className="text-2xl font-bold mb-3 text-yellow-400">Synopsis</h2>
                  <p className="text-gray-300 leading-relaxed text-lg">{movie.description}</p>
                </div>
              )}

              {/* Showtimes */}
              {movie.showtimes && movie.showtimes.length > 0 ? (
                <div className="mb-8">
                  <h2 className="text-2xl font-bold mb-4 text-yellow-400">Select Showtime</h2>
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 mb-6">
                    {movie.showtimes.map((st, idx) => {
                      const showtime = new Date(st)
                      const isSelected = selectedShowtime && new Date(selectedShowtime).getTime() === showtime.getTime()
                      return (
                        <button
                          key={idx}
                          onClick={() => setSelectedShowtime(st)}
                          className={`px-4 py-3 rounded-xl border-2 transition-all transform hover:scale-105 ${
                            isSelected
                              ? 'border-yellow-400 bg-yellow-400/20 text-white shadow-lg shadow-yellow-400/50'
                              : 'border-gray-600 text-gray-300 hover:border-yellow-400/50 hover:bg-yellow-400/10'
                          }`}
                        >
                          <div className="text-sm font-semibold">
                            {showtime.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                          </div>
                          <div className="text-lg font-bold">
                            {showtime.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}
                          </div>
                        </button>
                      )
                    })}
                  </div>
                </div>
              ) : (
                <div className="mb-6 p-4 bg-yellow-400/20 border border-yellow-400/50 rounded-xl">
                  <p className="text-yellow-200">No showtimes available. Please check back later.</p>
                </div>
              )}

              {/* Price and Book Button */}
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-6 bg-white/5 backdrop-blur-sm rounded-xl border border-white/10">
                {movie.price && (
                  <div>
                    <p className="text-gray-400 text-sm mb-1">Ticket Price</p>
                    <p className="text-3xl font-bold text-yellow-400">
                      ${movie.price.toFixed(2)} <span className="text-lg text-gray-400 font-normal">per ticket</span>
                    </p>
                  </div>
                )}
                <button
                  onClick={handleBookTicket}
                  disabled={!selectedShowtime}
                  className="w-full sm:w-auto px-8 py-4 bg-gradient-to-r from-yellow-400 to-orange-500 hover:from-yellow-500 hover:to-orange-600 disabled:from-gray-600 disabled:to-gray-700 disabled:cursor-not-allowed text-black font-bold text-lg rounded-xl transition-all shadow-2xl hover:shadow-yellow-500/50 transform hover:scale-105"
                >
                  {!user ? 'Sign In to Book' : selectedShowtime ? 'Book Tickets Now' : 'Select Showtime'}
                </button>
              </div>

              {/* Trailer */}
              {movie.trailer && (
                <div className="mt-8">
                  <h2 className="text-2xl font-bold mb-4 text-yellow-400">Watch Trailer</h2>
                  <div className="aspect-video rounded-xl overflow-hidden shadow-2xl">
                    <iframe
                      src={movie.trailer}
                      className="w-full h-full"
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                      allowFullScreen
                    ></iframe>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
