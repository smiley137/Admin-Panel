import React, { useEffect, useState } from 'react'
import { useParams, useSearchParams, useNavigate, Link } from 'react-router-dom'
import API from '../api'

export default function SeatSelection(){
  const { id } = useParams()
  const [searchParams] = useSearchParams()
  const navigate = useNavigate()
  const showtime = searchParams.get('showtime')
  
  const [movie, setMovie] = useState(null)
  const [seats, setSeats] = useState([])
  const [selectedSeats, setSelectedSeats] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function fetchData(){
      try {
        const [movieRes, seatsRes] = await Promise.all([
          API.get('/movies/' + id),
          API.get(`/seats/${id}/${encodeURIComponent(showtime)}`)
        ])
        setMovie(movieRes.data)
        setSeats(seatsRes.data)
      } catch (err) {
        console.error('Error fetching data:', err)
      }
      setLoading(false)
    }
    if (showtime) fetchData()
  }, [id, showtime])

  function toggleSeat(row, number){
    const seat = seats.find(s => s.row === row && s.number === number)
    if (seat?.isBooked) return
    
    setSelectedSeats(prev => {
      const exists = prev.find(s => s.row === row && s.number === number)
      if (exists) {
        return prev.filter(s => !(s.row === row && s.number === number))
      } else {
        return [...prev, { row, number }]
      }
    })
  }

  function getSeatStatus(row, number){
    const seat = seats.find(s => s.row === row && s.number === number)
    if (seat?.isBooked) return 'booked'
    const isSelected = selectedSeats.find(s => s.row === row && s.number === number)
    return isSelected ? 'selected' : 'available'
  }

  function handleContinue(){
    if (selectedSeats.length === 0) {
      alert('Please select at least one seat')
      return
    }
    navigate(`/snacks/${id}?showtime=${showtime}&seats=${JSON.stringify(selectedSeats)}`)
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-black flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-16 w-16 border-b-2 border-yellow-400"></div>
          <p className="mt-4 text-gray-300">Loading seat map...</p>
        </div>
      </div>
    )
  }

  const rows = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J']
  const seatsByRow = rows.map(row => ({
    row,
    seats: Array.from({ length: 10 }, (_, i) => i + 1)
  }))

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-black">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-black/80 backdrop-blur-md border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <Link to="/" className="flex items-center space-x-2">
              <div className="w-10 h-10 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-lg flex items-center justify-center">
                <span className="text-xl">🎬</span>
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-yellow-400 to-orange-500 bg-clip-text text-transparent">
                MovieHub
              </span>
            </Link>
            {movie && (
              <div className="text-right hidden sm:block">
                <p className="text-white font-semibold">{movie.title}</p>
                <p className="text-gray-400 text-sm">
                  {new Date(showtime).toLocaleString()}
                </p>
              </div>
            )}
          </div>
        </div>
      </nav>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 pt-24">
        {/* Screen */}
        <div className="mb-8 text-center">
          <div className="inline-block bg-gradient-to-b from-gray-700 via-gray-800 to-gray-900 rounded-2xl px-12 py-6 mb-4 shadow-2xl border border-white/10">
            <p className="text-white font-bold text-xl md:text-2xl">SCREEN</p>
            <div className="mt-2 h-1 bg-gradient-to-r from-transparent via-yellow-400 to-transparent"></div>
          </div>
        </div>

        {/* Seat Map */}
        <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-4 md:p-8 mb-8 border border-white/10">
          <div className="space-y-3">
            {seatsByRow.map(({ row, seats: rowSeats }) => (
              <div key={row} className="flex items-center gap-2 md:gap-4">
                <div className="w-8 md:w-12 text-white font-bold text-center text-lg">{row}</div>
                <div className="flex gap-1 md:gap-2 flex-1 justify-center">
                  {rowSeats.map(num => {
                    const status = getSeatStatus(row, num)
                    return (
                      <button
                        key={num}
                        onClick={() => toggleSeat(row, num)}
                        disabled={status === 'booked'}
                        className={`
                          w-8 h-8 md:w-12 md:h-12 rounded-lg text-xs md:text-sm font-bold
                          transition-all duration-200 transform hover:scale-110
                          ${status === 'booked' 
                            ? 'bg-red-600/50 cursor-not-allowed opacity-50 border border-red-500' 
                            : status === 'selected'
                            ? 'bg-gradient-to-br from-yellow-400 to-orange-500 text-black scale-110 shadow-lg shadow-yellow-400/50 border-2 border-yellow-400'
                            : 'bg-gray-700 hover:bg-gray-600 text-white border border-gray-600'
                          }
                        `}
                      >
                        {num}
                      </button>
                    )
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Legend */}
        <div className="flex flex-wrap justify-center gap-6 mb-8">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 bg-gray-700 rounded-lg border border-gray-600"></div>
            <span className="text-gray-300 text-sm">Available</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-lg border-2 border-yellow-400"></div>
            <span className="text-gray-300 text-sm">Selected</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 bg-red-600/50 rounded-lg border border-red-500 opacity-50"></div>
            <span className="text-gray-300 text-sm">Booked</span>
          </div>
        </div>

        {/* Selected Seats Summary */}
        {selectedSeats.length > 0 && (
          <div className="bg-gradient-to-r from-yellow-400/20 to-orange-500/20 border border-yellow-400/50 rounded-xl p-6 mb-6 backdrop-blur-sm">
            <p className="text-white font-semibold mb-2 text-lg">
              Selected Seats: {selectedSeats.map(s => `${s.row}${s.number}`).join(', ')}
            </p>
            {movie && (
              <p className="text-yellow-400 text-xl font-bold">
                Total: ${(selectedSeats.length * (movie.price || 10)).toFixed(2)}
              </p>
            )}
          </div>
        )}

        {/* Navigation */}
        <div className="flex flex-col sm:flex-row gap-4 justify-between">
          <Link
            to={`/movie/${id}`}
            className="px-6 py-3 bg-gray-700 hover:bg-gray-600 text-white rounded-xl transition-colors text-center"
          >
            ← Back to Movie
          </Link>
          <button
            onClick={handleContinue}
            disabled={selectedSeats.length === 0}
            className="px-8 py-3 bg-gradient-to-r from-yellow-400 to-orange-500 hover:from-yellow-500 hover:to-orange-600 disabled:from-gray-600 disabled:to-gray-700 disabled:cursor-not-allowed text-black font-bold rounded-xl transition-all shadow-lg hover:shadow-yellow-400/50 transform hover:scale-105"
          >
            Continue to Snacks →
          </button>
        </div>
      </div>
    </div>
  )
}
