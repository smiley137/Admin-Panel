import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import API from '../api'
import MovieCard from '../components/MovieCard'
import Modal from '../components/Modal'
import MovieForm from '../components/MovieForm'

export default function AdminPanel(){
  const [movies, setMovies] = useState([])
  const [loading, setLoading] = useState(true)
  const [open, setOpen] = useState(false)
  const [editing, setEditing] = useState(null)
  const [q, setQ] = useState('')
  const { user, logout } = useAuth()
  const navigate = useNavigate()

  async function fetchMovies(){
    setLoading(true)
    try {
      const res = await API.get('/movies?admin=true' + (q ? '&q=' + encodeURIComponent(q) : ''))
      setMovies(res.data)
    } catch (err) {
      console.error('Error fetching movies:', err)
    }
    setLoading(false)
  }

  useEffect(()=> { fetchMovies() }, [q])

  async function handleCreate(payload){
    try {
      await API.post('/movies', payload)
      setOpen(false)
      fetchMovies()
    } catch (err) {
      alert('Error creating movie: ' + (err.response?.data?.error || err.message))
    }
  }

  async function handleUpdate(id, payload){
    try {
      await API.put('/movies/' + id, payload)
      setEditing(null)
      setOpen(false)
      fetchMovies()
    } catch (err) {
      alert('Error updating movie: ' + (err.response?.data?.error || err.message))
    }
  }

  async function handleDelete(id){
    if(!confirm('Delete this movie?')) return
    try {
      await API.delete('/movies/' + id)
      fetchMovies()
    } catch (err) {
      alert('Error deleting movie: ' + (err.response?.data?.error || err.message))
    }
  }

  function openNew(){
    setEditing(null)
    setOpen(true)
  }

  function openEdit(movie){
    setEditing(movie)
    setOpen(true)
  }

  function onSearch(e){
    e.preventDefault()
    fetchMovies()
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-black">
      {/* Navigation */}
      <nav className="bg-black/80 backdrop-blur-md border-b border-white/10 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                </svg>
              </div>
              <div>
                <h1 className="text-xl font-bold text-white">Admin Dashboard</h1>
                <p className="text-gray-400 text-sm">{user?.email}</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <button
                onClick={() => navigate('/')}
                className="px-4 py-2 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-colors"
              >
                View Website
              </button>
              <button
                onClick={logout}
                className="px-4 py-2 rounded-lg bg-red-600 hover:bg-red-700 text-white transition-colors"
              >
                Logout
              </button>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-6">
            <div>
              <h2 className="text-3xl font-bold text-white mb-2">Movie Management</h2>
              <p className="text-gray-400">Manage your movie catalog</p>
            </div>
            <button
              onClick={openNew}
              className="px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-bold rounded-lg transition-all shadow-lg hover:shadow-xl transform hover:scale-105"
            >
              + Add New Movie
            </button>
          </div>

          {/* Search */}
          <form onSubmit={onSearch} className="max-w-md">
            <div className="relative">
              <input
                value={q}
                onChange={e=>setQ(e.target.value)}
                placeholder="Search movies..."
                className="w-full px-4 py-3 pl-10 pr-4 rounded-lg bg-white/10 border border-white/20 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <svg className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </div>
          </form>
        </div>

        {/* Movies Grid */}
        {loading ? (
          <div className="text-center py-20">
            <div className="inline-block animate-spin rounded-full h-16 w-16 border-b-2 border-blue-500"></div>
            <p className="mt-4 text-gray-400">Loading movies...</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {movies.length === 0 ? (
              <div className="col-span-full text-center py-20">
                <div className="text-6xl mb-4">🎬</div>
                <p className="text-gray-400 text-xl mb-4">No movies found</p>
                <button
                  onClick={openNew}
                  className="px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white font-bold rounded-lg"
                >
                  Add Your First Movie
                </button>
              </div>
            ) : movies.map(m=>(
              <MovieCard key={m._id} movie={m} onEdit={openEdit} onDelete={handleDelete} isAdmin={true} />
            ))}
          </div>
        )}
      </div>

      <Modal open={open} onClose={()=>setOpen(false)}>
        <h2 className="text-2xl font-bold text-white mb-6">{editing ? 'Edit Movie' : 'Add New Movie'}</h2>
        <MovieForm
          initial={editing || {}}
          onCancel={()=>{ setOpen(false); setEditing(null); }}
          onSubmit={(payload)=> {
            if(editing) handleUpdate(editing._id, payload)
            else handleCreate(payload)
          }}
        />
      </Modal>
    </div>
  )
}
