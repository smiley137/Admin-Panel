import React, { useEffect, useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import API from '../api'

export default function BookingSuccess(){
  const { id } = useParams()
  const [booking, setBooking] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function fetchBooking(){
      try {
        const res = await API.get('/bookings/' + id)
        setBooking(res.data)
      } catch (err) {
        console.error('Error fetching booking:', err)
      }
      setLoading(false)
    }
    fetchBooking()
  }, [id])

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-white"></div>
          <p className="mt-4 text-gray-300">Loading...</p>
        </div>
      </div>
    )
  }

  if (!booking) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-300 text-xl mb-4">Booking not found</p>
          <Link to="/" className="text-blue-400 hover:text-blue-300">Go back home</Link>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 flex items-center justify-center px-4">
      <div className="max-w-2xl w-full bg-white/5 backdrop-blur-sm rounded-lg p-8 md:p-12 border border-white/10 text-center">
        <div className="mb-6">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-green-500 rounded-full mb-4">
            <svg className="w-12 h-12 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">Booking Confirmed!</h1>
          <p className="text-gray-300">Your tickets have been booked successfully</p>
        </div>

        <div className="bg-white/5 rounded-lg p-6 mb-6 text-left">
          {booking.movieId && (
            <div className="mb-4">
              <h2 className="text-xl font-semibold text-white mb-2">{booking.movieId.title}</h2>
              <p className="text-gray-300 text-sm">
                Showtime: {new Date(booking.showtime).toLocaleString()}
              </p>
            </div>
          )}
          
          <div className="mb-4">
            <p className="text-gray-300 text-sm mb-1">Seats</p>
            <p className="text-white font-semibold">
              {booking.seats.map(s => `${s.row}${s.number}`).join(', ')}
            </p>
          </div>

          {booking.snacks && booking.snacks.length > 0 && (
            <div className="mb-4">
              <p className="text-gray-300 text-sm mb-1">Snacks & Drinks</p>
              {booking.snacks.map((item, idx) => (
                <p key={idx} className="text-white text-sm">
                  {item.snackId?.name || 'Snack'} × {item.quantity}
                </p>
              ))}
            </div>
          )}

          <div className="border-t border-gray-700 pt-4">
            <div className="flex justify-between items-center">
              <span className="text-gray-300">Total Amount</span>
              <span className="text-2xl font-bold text-blue-400">${booking.totalAmount.toFixed(2)}</span>
            </div>
            {booking.paymentId && (
              <p className="text-gray-400 text-xs mt-2">Payment ID: {booking.paymentId}</p>
            )}
          </div>
        </div>

        <div className="space-y-3">
          <Link
            to="/"
            className="block w-full px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg transition-colors"
          >
            Back to Home
          </Link>
          <p className="text-gray-400 text-sm">
            A confirmation email has been sent to your registered email address.
          </p>
        </div>
      </div>
    </div>
  )
}

