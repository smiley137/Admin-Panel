import React, { useEffect, useState } from 'react'
import { useParams, useSearchParams, useNavigate } from 'react-router-dom'
import API from '../api'

export default function Checkout(){
  const { id } = useParams()
  const [searchParams] = useSearchParams()
  const navigate = useNavigate()
  const showtime = searchParams.get('showtime')
  const seatsParam = searchParams.get('seats')
  const snacksParam = searchParams.get('snacks')
  const selectedSeats = seatsParam ? JSON.parse(seatsParam) : []
  const selectedSnacks = snacksParam ? JSON.parse(snacksParam) : {}
  
  const [movie, setMovie] = useState(null)
  const [snacks, setSnacks] = useState([])
  const [loading, setLoading] = useState(true)
  const [processing, setProcessing] = useState(false)
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    cardNumber: '',
    expiryDate: '',
    cvv: '',
    billingAddress: ''
  })

  useEffect(() => {
    async function fetchData(){
      try {
        const [movieRes, snacksRes] = await Promise.all([
          API.get('/movies/' + id),
          API.get('/snacks')
        ])
        setMovie(movieRes.data)
        setSnacks(snacksRes.data)
      } catch (err) {
        console.error('Error fetching data:', err)
      }
      setLoading(false)
    }
    fetchData()
  }, [id])

  function calculateTotal(){
    const ticketPrice = (movie?.price || 10) * selectedSeats.length
    const snackTotal = Object.entries(selectedSnacks).reduce((sum, [snackId, quantity]) => {
      const snack = snacks.find(s => s._id === snackId)
      return sum + (snack?.price || 0) * quantity
    }, 0)
    return ticketPrice + snackTotal
  }

  async function handleCheckout(e){
    e.preventDefault()
    setProcessing(true)

    try {
      // Prepare booking data
      const snackItems = Object.entries(selectedSnacks).map(([snackId, quantity]) => ({
        snackId,
        quantity
      }))

      const bookingData = {
        movieId: id,
        seats: selectedSeats,
        snacks: snackItems,
        showtime: showtime,
        totalAmount: calculateTotal()
      }

      // Create booking
      const bookingRes = await API.post('/bookings', bookingData)
      const bookingId = bookingRes.data._id

      // Simulate payment processing (in real app, integrate with payment gateway)
      // For demo, we'll just update the booking with payment status
      await new Promise(resolve => setTimeout(resolve, 2000)) // Simulate payment delay
      
      const paymentId = 'PAY_' + Date.now() // Generate mock payment ID
      await API.put(`/bookings/${bookingId}/payment`, {
        paymentId,
        paymentStatus: 'completed'
      })

      // Redirect to success page
      navigate(`/booking-success/${bookingId}`)
    } catch (err) {
      console.error('Checkout error:', err)
      alert('Payment failed. Please try again.')
      setProcessing(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-white"></div>
          <p className="mt-4 text-gray-300">Loading...</p>
        </div>
      </div>
    )
  }

  const total = calculateTotal()
  const snackEntries = Object.entries(selectedSnacks)

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
      <header className="bg-black/50 backdrop-blur-sm sticky top-0 z-40 border-b border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <h1 className="text-xl md:text-2xl font-bold text-white">Checkout</h1>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Payment Form */}
          <div className="lg:col-span-2">
            <form onSubmit={handleCheckout} className="bg-white/5 backdrop-blur-sm rounded-lg p-6 md:p-8 border border-white/10">
              <h2 className="text-2xl font-bold text-white mb-6">Payment Information</h2>
              
              {/* Personal Info */}
              <div className="space-y-4 mb-6">
                <div>
                  <label className="block text-gray-300 mb-2">Full Name</label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    className="w-full px-4 py-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="John Doe"
                  />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-gray-300 mb-2">Email</label>
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({...formData, email: e.target.value})}
                      className="w-full px-4 py-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="john@example.com"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-300 mb-2">Phone</label>
                    <input
                      type="tel"
                      required
                      value={formData.phone}
                      onChange={(e) => setFormData({...formData, phone: e.target.value})}
                      className="w-full px-4 py-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="+1 234 567 8900"
                    />
                  </div>
                </div>
              </div>

              {/* Card Info */}
              <div className="space-y-4 mb-6">
                <h3 className="text-xl font-semibold text-white">Card Details</h3>
                <div>
                  <label className="block text-gray-300 mb-2">Card Number</label>
                  <input
                    type="text"
                    required
                    maxLength="19"
                    value={formData.cardNumber}
                    onChange={(e) => setFormData({...formData, cardNumber: e.target.value.replace(/\s/g, '').replace(/(.{4})/g, '$1 ').trim()})}
                    className="w-full px-4 py-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="1234 5678 9012 3456"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-gray-300 mb-2">Expiry Date</label>
                    <input
                      type="text"
                      required
                      maxLength="5"
                      value={formData.expiryDate}
                      onChange={(e) => {
                        let value = e.target.value.replace(/\D/g, '')
                        if (value.length >= 2) value = value.slice(0, 2) + '/' + value.slice(2, 4)
                        setFormData({...formData, expiryDate: value})
                      }}
                      className="w-full px-4 py-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="MM/YY"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-300 mb-2">CVV</label>
                    <input
                      type="text"
                      required
                      maxLength="4"
                      value={formData.cvv}
                      onChange={(e) => setFormData({...formData, cvv: e.target.value.replace(/\D/g, '')})}
                      className="w-full px-4 py-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="123"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-gray-300 mb-2">Billing Address</label>
                  <input
                    type="text"
                    required
                    value={formData.billingAddress}
                    onChange={(e) => setFormData({...formData, billingAddress: e.target.value})}
                    className="w-full px-4 py-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="123 Main St, City, State, ZIP"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={processing}
                className="w-full px-6 py-4 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 disabled:cursor-not-allowed text-white font-bold text-lg rounded-lg transition-colors"
              >
                {processing ? 'Processing Payment...' : 'Complete Payment'}
              </button>
            </form>
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="bg-white/5 backdrop-blur-sm rounded-lg p-6 border border-white/10 sticky top-24">
              <h2 className="text-xl font-bold text-white mb-4">Order Summary</h2>
              
              {movie && (
                <div className="mb-4 pb-4 border-b border-gray-700">
                  <p className="text-white font-semibold mb-2">{movie.title}</p>
                  <p className="text-gray-400 text-sm">
                    {new Date(showtime).toLocaleString()}
                  </p>
                </div>
              )}

              <div className="mb-4">
                <p className="text-gray-300 text-sm mb-2">Seats</p>
                <p className="text-white">
                  {selectedSeats.map(s => `${s.row}${s.number}`).join(', ')}
                </p>
              </div>

              <div className="mb-4">
                <p className="text-gray-300 text-sm mb-2">Tickets</p>
                <div className="flex justify-between text-white">
                  <span>{selectedSeats.length} × ${(movie?.price || 10).toFixed(2)}</span>
                  <span>${((movie?.price || 10) * selectedSeats.length).toFixed(2)}</span>
                </div>
              </div>

              {snackEntries.length > 0 && (
                <div className="mb-4 border-t border-gray-700 pt-4">
                  <p className="text-gray-300 text-sm mb-2">Snacks & Drinks</p>
                  {snackEntries.map(([snackId, quantity]) => {
                    const snack = snacks.find(s => s._id === snackId)
                    if (!snack) return null
                    return (
                      <div key={snackId} className="flex justify-between text-white text-sm mb-1">
                        <span>{snack.name} × {quantity}</span>
                        <span>${(snack.price * quantity).toFixed(2)}</span>
                      </div>
                    )
                  })}
                </div>
              )}

              <div className="border-t border-gray-700 pt-4 mt-4">
                <div className="flex justify-between items-center">
                  <span className="text-lg font-bold text-white">Total</span>
                  <span className="text-2xl font-bold text-blue-400">${total.toFixed(2)}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

