import React, { useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import API from '../api'

export default function Home(){
  const [movies, setMovies] = useState([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState('')
  const [featuredMovie, setFeaturedMovie] = useState(null)
  const { user, logout } = useAuth()
  const navigate = useNavigate()

  async function fetchMovies(){
    setLoading(true)
    try {
      const res = await API.get('/movies' + (searchQuery ? '?q=' + encodeURIComponent(searchQuery) : ''))
      setMovies(res.data)
      if (res.data.length > 0 && !featuredMovie) {
        setFeaturedMovie(res.data[0])
      }
    } catch (err) {
      console.error('Error fetching movies:', err)
    }
    setLoading(false)
  }

  useEffect(()=> { fetchMovies() }, [searchQuery])

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-black">
      {/* Navigation Bar */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-black/80 backdrop-blur-md border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 md:h-20">
            <Link to="/" className="flex items-center space-x-2 group">
              <div className="w-10 h-10 md:w-12 md:h-12 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-lg flex items-center justify-center transform group-hover:scale-110 transition-transform">
                <span className="text-xl md:text-2xl">🎬</span>
              </div>
              <span className="text-xl md:text-2xl font-bold bg-gradient-to-r from-yellow-400 to-orange-500 bg-clip-text text-transparent">
                MovieHub
              </span>
            </Link>

            <div className="flex items-center space-x-4">
              {/* Search Bar */}
              <div className="hidden md:block relative">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search movies..."
                  className="w-64 px-4 py-2 pl-10 rounded-full bg-white/10 border border-white/20 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent"
                />
                <svg className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </div>

              {user ? (
                <div className="flex items-center space-x-3">
                  <div className="hidden sm:block text-right">
                    <p className="text-white text-sm font-medium">{user.name}</p>
                    <p className="text-gray-400 text-xs">{user.email}</p>
                  </div>
                  <button
                    onClick={logout}
                    className="px-4 py-2 rounded-full bg-red-600 hover:bg-red-700 text-white text-sm font-medium transition-colors"
                  >
                    Logout
                  </button>
                </div>
              ) : (
                <Link
                  to="/login"
                  className="px-4 py-2 rounded-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white text-sm font-medium transition-all shadow-lg hover:shadow-xl"
                >
                  Sign In
                </Link>
              )}
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section with Featured Movie */}
      {featuredMovie && !searchQuery && (
        <section className="relative h-[70vh] md:h-[85vh] overflow-hidden mt-16 md:mt-20">
          <div 
            className="absolute inset-0 bg-cover bg-center"
            style={{
              backgroundImage: `linear-gradient(to bottom, rgba(0,0,0,0.3), rgba(0,0,0,0.8)), url(${featuredMovie.poster || 'https://via.placeholder.com/1920x1080'})`
            }}
          >
            <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/50 to-transparent"></div>
          </div>
          
          <div className="relative h-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center">
            <div className="max-w-2xl">
              <div className="mb-4">
                <span className="inline-block px-3 py-1 bg-yellow-400/20 border border-yellow-400/50 rounded-full text-yellow-400 text-sm font-semibold">
                  Now Showing
                </span>
              </div>
              <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-white mb-4 leading-tight">
                {featuredMovie.title}
              </h1>
              <div className="flex flex-wrap items-center gap-4 mb-6 text-white">
                {featuredMovie.rating && (
                  <div className="flex items-center space-x-1">
                    <span className="text-yellow-400 text-xl">⭐</span>
                    <span className="font-bold">{featuredMovie.rating.toFixed(1)}</span>
                  </div>
                )}
                {featuredMovie.year && <span>• {featuredMovie.year}</span>}
                {featuredMovie.genre && <span>• {featuredMovie.genre}</span>}
                {featuredMovie.duration && <span>• {featuredMovie.duration} min</span>}
              </div>
              {featuredMovie.description && (
                <p className="text-gray-300 text-lg mb-8 line-clamp-3">
                  {featuredMovie.description}
                </p>
              )}
              <div className="flex flex-wrap gap-4">
                <Link
                  to={`/movie/${featuredMovie._id}`}
                  className="px-8 py-4 bg-gradient-to-r from-yellow-400 to-orange-500 hover:from-yellow-500 hover:to-orange-600 text-black font-bold rounded-lg transition-all shadow-2xl hover:shadow-yellow-500/50 transform hover:scale-105"
                >
                  Book Now
                </Link>
                {featuredMovie.trailer && (
                  <a
                    href={featuredMovie.trailer}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-8 py-4 bg-white/10 hover:bg-white/20 backdrop-blur-sm border border-white/30 text-white font-bold rounded-lg transition-all"
                  >
                    Watch Trailer
                  </a>
                )}
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Movies Section */}
      <section className={`${featuredMovie && !searchQuery ? 'py-16' : 'pt-32 pb-16'} max-w-7xl mx-auto px-4 sm:px-6 lg:px-8`}>
        <div className="mb-8">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-2">
            {searchQuery ? `Search Results for "${searchQuery}"` : 'Now Showing'}
          </h2>
          <p className="text-gray-400">
            {searchQuery ? `Found ${movies.length} movies` : 'Book your tickets now'}
          </p>
        </div>

        {/* Mobile Search */}
        <div className="md:hidden mb-6">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search movies..."
            className="w-full px-4 py-3 pl-10 rounded-lg bg-white/10 border border-white/20 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-yellow-400"
          />
        </div>

        {loading ? (
          <div className="text-center py-20">
            <div className="inline-block animate-spin rounded-full h-16 w-16 border-b-2 border-yellow-400"></div>
            <p className="mt-4 text-gray-400">Loading amazing movies...</p>
          </div>
        ) : movies.length === 0 ? (
          <div className="text-center py-20">
            <div className="text-6xl mb-4">🎭</div>
            <p className="text-gray-400 text-xl">No movies found</p>
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="mt-4 text-yellow-400 hover:text-yellow-300"
              >
                Clear search
              </button>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 md:gap-6">
            {movies.map(movie => (
              <Link
                key={movie._id}
                to={`/movie/${movie._id}`}
                className="group relative bg-white/5 backdrop-blur-sm rounded-xl overflow-hidden border border-white/10 hover:border-yellow-400/50 transition-all duration-300 hover:scale-105 hover:shadow-2xl hover:shadow-yellow-500/20"
              >
                <div className="aspect-[2/3] relative overflow-hidden">
                  <img
                    src={movie.poster || 'https://via.placeholder.com/300x450?text=No+Poster'}
                    alt={movie.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                  {movie.rating && (
                    <div className="absolute top-2 right-2 bg-yellow-400 text-black px-2 py-1 rounded-full text-xs font-bold shadow-lg">
                      ⭐ {movie.rating.toFixed(1)}
                    </div>
                  )}
                  <div className="absolute bottom-0 left-0 right-0 p-3 transform translate-y-full group-hover:translate-y-0 transition-transform duration-300">
                    <p className="text-white text-sm font-semibold line-clamp-2">{movie.title}</p>
                  </div>
                </div>
                <div className="p-3">
                  <h3 className="font-bold text-white text-sm md:text-base mb-1 line-clamp-1 group-hover:text-yellow-400 transition-colors">
                    {movie.title}
                  </h3>
                  <p className="text-gray-400 text-xs">
                    {movie.year && <span>{movie.year}</span>}
                    {movie.genre && <span> • {movie.genre}</span>}
                  </p>
                  {movie.price && (
                    <p className="text-yellow-400 font-bold text-sm mt-1">${movie.price.toFixed(2)}</p>
                  )}
                </div>
              </Link>
            ))}
          </div>
        )}
      </section>

      {/* Footer */}
      <footer className="bg-black/50 border-t border-white/10 py-8 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-gray-400 text-sm">
            © 2024 MovieHub. Experience the magic of cinema.
          </p>
        </div>
      </footer>
    </div>
  )
}
