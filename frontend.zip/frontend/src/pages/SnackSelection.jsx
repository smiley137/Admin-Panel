import React, { useEffect, useState } from 'react'
import { useParams, useSearchParams, useNavigate, Link } from 'react-router-dom'
import API from '../api'

export default function SnackSelection(){
  const { id } = useParams()
  const [searchParams] = useSearchParams()
  const navigate = useNavigate()
  const showtime = searchParams.get('showtime')
  const seatsParam = searchParams.get('seats')
  const selectedSeats = seatsParam ? JSON.parse(seatsParam) : []
  
  const [movie, setMovie] = useState(null)
  const [snacks, setSnacks] = useState([])
  const [selectedSnacks, setSelectedSnacks] = useState({}) // { snackId: quantity }
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function fetchData(){
      try {
        const [movieRes, snacksRes] = await Promise.all([
          API.get('/movies/' + id),
          API.get('/snacks')
        ])
        setMovie(movieRes.data)
        setSnacks(snacksRes.data)
      } catch (err) {
        console.error('Error fetching data:', err)
      }
      setLoading(false)
    }
    fetchData()
  }, [id])

  function updateSnackQuantity(snackId, delta){
    setSelectedSnacks(prev => {
      const current = prev[snackId] || 0
      const newQuantity = Math.max(0, current + delta)
      if (newQuantity === 0) {
        const { [snackId]: _, ...rest } = prev
        return rest
      }
      return { ...prev, [snackId]: newQuantity }
    })
  }

  function calculateTotal(){
    const ticketPrice = (movie?.price || 10) * selectedSeats.length
    const snackTotal = Object.entries(selectedSnacks).reduce((sum, [snackId, quantity]) => {
      const snack = snacks.find(s => s._id === snackId)
      return sum + (snack?.price || 0) * quantity
    }, 0)
    return ticketPrice + snackTotal
  }

  function handleContinue(){
    navigate(`/checkout/${id}?showtime=${showtime}&seats=${seatsParam}&snacks=${JSON.stringify(selectedSnacks)}`)
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-white"></div>
          <p className="mt-4 text-gray-300">Loading...</p>
        </div>
      </div>
    )
  }

  const total = calculateTotal()
  const snackEntries = Object.entries(selectedSnacks)

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
      <nav className="fixed top-0 left-0 right-0 z-50 bg-black/80 backdrop-blur-md border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <Link to="/" className="flex items-center space-x-2">
              <div className="w-10 h-10 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-lg flex items-center justify-center">
                <span className="text-xl">🎬</span>
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-yellow-400 to-orange-500 bg-clip-text text-transparent">
                MovieHub
              </span>
            </Link>
            <h1 className="text-xl md:text-2xl font-bold text-white">Select Snacks & Drinks</h1>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 pt-24">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Snacks Grid */}
          <div className="lg:col-span-2">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 md:gap-6">
              {snacks.map(snack => {
                const quantity = selectedSnacks[snack._id] || 0
                return (
                  <div
                    key={snack._id}
                    className="bg-white/5 backdrop-blur-sm rounded-xl p-4 border border-white/10 hover:border-yellow-400/50 transition-all transform hover:scale-105"
                  >
                    <div className="aspect-video mb-3 rounded-lg overflow-hidden bg-gray-700">
                      {snack.image ? (
                        <img src={snack.image} alt={snack.name} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-gray-400">
                          🍿
                        </div>
                      )}
                    </div>
                    <h3 className="text-white font-semibold mb-1">{snack.name}</h3>
                    {snack.description && (
                      <p className="text-gray-400 text-sm mb-2">{snack.description}</p>
                    )}
                    <div className="flex items-center justify-between">
                      <p className="text-yellow-400 font-bold">${snack.price.toFixed(2)}</p>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => updateSnackQuantity(snack._id, -1)}
                          disabled={quantity === 0}
                          className="w-8 h-8 rounded bg-gray-600 hover:bg-gray-500 disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold"
                        >
                          -
                        </button>
                        <span className="text-white font-semibold w-8 text-center">{quantity}</span>
                        <button
                          onClick={() => updateSnackQuantity(snack._id, 1)}
                          className="w-8 h-8 rounded-lg bg-gradient-to-r from-yellow-400 to-orange-500 hover:from-yellow-500 hover:to-orange-600 text-black font-bold"
                        >
                          +
                        </button>
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
            {snacks.length === 0 && (
              <div className="text-center py-12 text-gray-400">
                No snacks available
              </div>
            )}
          </div>

          {/* Summary Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white/5 backdrop-blur-sm rounded-lg p-6 border border-white/10 sticky top-24">
              <h2 className="text-xl font-bold text-white mb-4">Order Summary</h2>
              
              {/* Tickets */}
              <div className="mb-4">
                <p className="text-gray-300 text-sm mb-2">Tickets</p>
                <div className="flex justify-between text-white">
                  <span>{selectedSeats.length} × ${(movie?.price || 10).toFixed(2)}</span>
                  <span>${((movie?.price || 10) * selectedSeats.length).toFixed(2)}</span>
                </div>
              </div>

              {/* Snacks */}
              {snackEntries.length > 0 && (
                <div className="mb-4 border-t border-gray-700 pt-4">
                  <p className="text-gray-300 text-sm mb-2">Snacks & Drinks</p>
                  {snackEntries.map(([snackId, quantity]) => {
                    const snack = snacks.find(s => s._id === snackId)
                    if (!snack) return null
                    return (
                      <div key={snackId} className="flex justify-between text-white text-sm mb-1">
                        <span>{snack.name} × {quantity}</span>
                        <span>${(snack.price * quantity).toFixed(2)}</span>
                      </div>
                    )
                  })}
                </div>
              )}

              {/* Total */}
              <div className="border-t border-gray-700 pt-4 mt-4">
                <div className="flex justify-between items-center">
                  <span className="text-lg font-bold text-white">Total</span>
                  <span className="text-2xl font-bold text-yellow-400">${total.toFixed(2)}</span>
                </div>
              </div>

              {/* Navigation */}
              <div className="mt-6 space-y-3">
                <button
                  onClick={() => navigate(-1)}
                  className="w-full px-4 py-3 bg-gray-600 hover:bg-gray-700 text-white rounded-lg transition-colors"
                >
                  Back
                </button>
                <button
                  onClick={handleContinue}
                  className="w-full px-4 py-3 bg-gradient-to-r from-yellow-400 to-orange-500 hover:from-yellow-500 hover:to-orange-600 text-black font-bold rounded-xl transition-all shadow-lg hover:shadow-yellow-400/50"
                >
                  Proceed to Checkout
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

