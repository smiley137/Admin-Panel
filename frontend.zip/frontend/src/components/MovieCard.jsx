import React from 'react'

export default function MovieCard({ movie, onEdit, onDelete, isAdmin = false }){
  return (
    <div className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow p-4 md:p-6 flex flex-col sm:flex-row gap-4">
      <img 
        src={movie.poster || 'https://via.placeholder.com/120x160'} 
        alt="poster" 
        className="w-full sm:w-24 md:w-32 h-48 sm:h-32 md:h-40 object-cover rounded-lg flex-shrink-0" 
      />
      <div className="flex-1 min-w-0">
        <h3 className="text-lg md:text-xl font-semibold text-gray-800 mb-1">
          {movie.title} 
          {movie.year && <span className="text-sm text-gray-500">({movie.year})</span>}
        </h3>
        <p className="text-sm text-gray-600 mb-2">
          {movie.genre && <span>{movie.genre}</span>}
          {movie.director && <span>{movie.genre ? ' • ' : ''}{movie.director}</span>}
        </p>
        {movie.rating && (
          <p className="text-sm text-yellow-600 font-semibold mb-2">⭐ {movie.rating.toFixed(1)}/10</p>
        )}
        {movie.price && (
          <p className="text-sm text-green-600 font-semibold mb-2">${movie.price.toFixed(2)}</p>
        )}
        {isAdmin && (
          <div className="mt-4 flex flex-wrap gap-2">
            <button 
              onClick={() => onEdit(movie)} 
              className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-sm transition-colors"
            >
              Edit
            </button>
            <button 
              onClick={() => onDelete(movie._id)} 
              className="px-3 py-1.5 rounded-lg bg-red-500 hover:bg-red-600 text-white text-sm transition-colors"
            >
              Delete
            </button>
            {movie.isActive !== undefined && (
              <span className={`px-3 py-1.5 rounded-lg text-xs font-semibold ${
                movie.isActive ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
              }`}>
                {movie.isActive ? 'Active' : 'Inactive'}
              </span>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
