import React, { useState, useEffect } from 'react'

const defaultForm = {
  title: '', director: '', year: '', genre: '', rating: '', poster: '',
  description: '', duration: '', price: '', trailer: '', language: 'English',
  cast: '', showtimes: [], isActive: true
}

function normalizeTrailer(url = '') {
  const trimmed = url.trim()
  if (!trimmed) return ''
  try {
    const parsed = new URL(trimmed)
    if (parsed.hostname.includes('youtube.com')) {
      if (parsed.pathname.startsWith('/embed/')) {
        return `https://www.youtube.com${parsed.pathname}`
      }
      const videoId = parsed.searchParams.get('v')
      if (videoId) {
        return `https://www.youtube.com/embed/${videoId}`
      }
    }
    if (parsed.hostname === 'youtu.be') {
      return `https://www.youtube.com/embed/${parsed.pathname.replace('/', '')}`
    }
    return trimmed
  } catch (err) {
    return trimmed
  }
}

function formatDateTimeLocal(dateLike) {
  const d = (dateLike instanceof Date) ? dateLike : new Date(dateLike)
  if (isNaN(d.getTime())) return ''
  const pad = n => String(n).padStart(2, '0')
  const yyyy = d.getFullYear()
  const mm = pad(d.getMonth() + 1)
  const dd = pad(d.getDate())
  const hh = pad(d.getHours())
  const min = pad(d.getMinutes())
  return `${yyyy}-${mm}-${dd}T${hh}:${min}`
}

export default function MovieForm({ initial = {}, onCancel, onSubmit }){
  const [form, setForm] = useState({ ...defaultForm, ...initial })
  
  useEffect(() => {
    const processed = { ...defaultForm, ...initial }
    if (initial.cast && Array.isArray(initial.cast)) {
      processed.cast = initial.cast.join(', ')
    }
    // normalize incoming showtimes to array of datetime-local strings
    if (initial.showtimes && Array.isArray(initial.showtimes)) {
      processed.showtimes = initial.showtimes.map(st => formatDateTimeLocal(st))
    } else {
      processed.showtimes = []
    }
    setForm(processed)
  }, [initial])

  function change(e){
    const { name, value, type, checked } = e.target
    setForm(s => ({ ...s, [name]: type === 'checkbox' ? checked : value }))
  }

  function changeShowtime(index, value){
    setForm(s => {
      const next = Array.isArray(s.showtimes) ? [...s.showtimes] : []
      next[index] = value
      return { ...s, showtimes: next }
    })
  }

  function addShowtime(){
    setForm(s => {
      const next = Array.isArray(s.showtimes) ? [...s.showtimes] : []
      next.push(formatDateTimeLocal(new Date()))
      return { ...s, showtimes: next }
    })
  }

  function removeShowtime(index){
    setForm(s => {
      const next = Array.isArray(s.showtimes) ? [...s.showtimes] : []
      next.splice(index, 1)
      return { ...s, showtimes: next }
    })
  }

  function submit(e){
    e.preventDefault();
    const payload = {
      ...form,
      year: form.year ? Number(form.year) : undefined,
      rating: form.rating ? Number(form.rating) : undefined,
      duration: form.duration ? Number(form.duration) : undefined,
      price: form.price ? Number(form.price) : undefined,
      cast: form.cast ? form.cast.split(',').map(s => s.trim()).filter(Boolean) : [],
      showtimes: Array.isArray(form.showtimes)
        ? form.showtimes
            .map(st => (typeof st === 'string' ? st.trim() : st))
            .filter(Boolean)
            .map(st => new Date(st))
            .filter(d => !isNaN(d.getTime()))
        : [],
      trailer: form.trailer ? normalizeTrailer(form.trailer) : undefined,
      isActive: form.isActive !== undefined ? form.isActive : true
    }
    onSubmit(payload)
  }

  return (
    <form onSubmit={submit} className="space-y-4 max-h-[70vh] overflow-y-auto pr-2">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">Title *</label>
        <input name="title" value={form.title} onChange={change} placeholder="Movie Title" className="w-full p-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500" required />
      </div>
      
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Director</label>
          <input name="director" value={form.director} onChange={change} placeholder="Director Name" className="w-full p-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500" />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Year</label>
          <input name="year" type="number" value={form.year} onChange={change} placeholder="2024" className="w-full p-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500" />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Genre</label>
          <input name="genre" value={form.genre} onChange={change} placeholder="Action, Drama, etc." className="w-full p-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500" />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Rating (0-10)</label>
          <input name="rating" type="number" min="0" max="10" step="0.1" value={form.rating} onChange={change} placeholder="8.5" className="w-full p-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500" />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">Poster URL</label>
        <input name="poster" value={form.poster} onChange={change} placeholder="https://example.com/poster.jpg" className="w-full p-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500" />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
        <textarea name="description" value={form.description} onChange={change} placeholder="Movie synopsis..." rows="3" className="w-full p-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500" />
      </div>

      <div className="grid grid-cols-3 gap-3">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Duration (min)</label>
          <input name="duration" type="number" value={form.duration} onChange={change} placeholder="120" className="w-full p-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500" />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Price ($)</label>
          <input name="price" type="number" step="0.01" value={form.price} onChange={change} placeholder="10.00" className="w-full p-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500" />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Language</label>
          <input name="language" value={form.language} onChange={change} placeholder="English" className="w-full p-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500" />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">Cast (comma-separated)</label>
        <input name="cast" value={form.cast} onChange={change} placeholder="Actor 1, Actor 2, Actor 3" className="w-full p-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500" />
      </div>

      <div>
        <div className="flex items-center justify-between mb-2">
          <label className="block text-sm font-medium text-gray-700">Showtimes</label>
          <button type="button" onClick={addShowtime} className="px-3 py-1 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-sm">
            + Add Showtime
          </button>
        </div>
        <div className="space-y-2">
          {(form.showtimes || []).map((st, idx) => (
            <div key={idx} className="flex items-center gap-2">
              <input
                type="datetime-local"
                value={st}
                onChange={(e)=> changeShowtime(idx, e.target.value)}
                className="flex-1 p-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <button
                type="button"
                onClick={()=> removeShowtime(idx)}
                className="px-3 py-2 rounded-lg border border-gray-300 hover:bg-gray-50"
                aria-label="Remove showtime"
              >
                Remove
              </button>
            </div>
          ))}
          {(!form.showtimes || form.showtimes.length === 0) && (
            <div className="text-sm text-gray-500">No showtimes added yet. Click “Add Showtime”.</div>
          )}
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">Trailer URL (YouTube embed)</label>
        <input name="trailer" value={form.trailer} onChange={change} placeholder="https://www.youtube.com/embed/..." className="w-full p-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500" />
      </div>

      <div className="flex items-center gap-2">
        <input name="isActive" type="checkbox" checked={form.isActive} onChange={change} className="w-4 h-4" />
        <label className="text-sm font-medium text-gray-700">Active (visible on user website)</label>
      </div>

      <div className="flex gap-2 justify-end pt-2">
        <button type="button" onClick={onCancel} className="px-4 py-2 rounded-lg border border-gray-300 hover:bg-gray-50 transition-colors">Cancel</button>
        <button type="submit" className="px-4 py-2 rounded-lg bg-green-600 hover:bg-green-700 text-white transition-colors">Save</button>
      </div>
    </form>
  )
}
