import React from 'react'
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import { AuthProvider } from './context/AuthContext'
import ProtectedRoute from './components/ProtectedRoute'
import Home from './pages/Home'
import Login from './pages/Login'
import AdminLogin from './pages/AdminLogin'
import AdminPanel from './pages/AdminPanel'
import MovieDetail from './pages/MovieDetail'
import SeatSelection from './pages/SeatSelection'
import SnackSelection from './pages/SnackSelection'
import Checkout from './pages/Checkout'
import BookingSuccess from './pages/BookingSuccess'

export default function App(){
  return (
    <AuthProvider>
      <Router>
        <Routes>
          {/* Public Routes */}
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/admin/login" element={<AdminLogin />} />
          <Route path="/movie/:id" element={<MovieDetail />} />
          
          {/* Protected User Routes */}
          <Route path="/booking/:id" element={<ProtectedRoute><SeatSelection /></ProtectedRoute>} />
          <Route path="/snacks/:id" element={<ProtectedRoute><SnackSelection /></ProtectedRoute>} />
          <Route path="/checkout/:id" element={<ProtectedRoute><Checkout /></ProtectedRoute>} />
          <Route path="/booking-success/:id" element={<ProtectedRoute><BookingSuccess /></ProtectedRoute>} />
          
          {/* Protected Admin Routes */}
          <Route path="/admin" element={<ProtectedRoute requireAdmin={true}><AdminPanel /></ProtectedRoute>} />
        </Routes>
      </Router>
    </AuthProvider>
  )
}
